## Oxford Cats Dataset

This is the dataset of cat pictures, which is a subset of [Oxford-IIIT Pet Dataset](https://www.robots.ox.ac.uk/~vgg/data/pets/).
It contais images of different breeds of cats, 10 images of each.


## License

The dataset is available to download for commercial/research purposes under a 
Creative Commons Attribution-ShareAlike 4.0 International License. 
The copyright remains with the original owners of the images.